#include <Elementary.h>

#define WIDTH 800
#define HEIGHT 600
#define edj_local "/home/gabriel/edje_player/edje_player.edj"

static const char commands[] = \
  "commands are:\n"
  "\tEsc - exit\n"
  "\tleft \n"
  "\tright \n";

//static Eina_Bool right_rect_show = EINA_TRUE;
static int changed = 0;

static void
_on_keydown(void        *data,
            Evas        *evas EINA_UNUSED,
            Evas_Object *o EINA_UNUSED,
            void        *einfo)
{
   Evas_Event_Key_Down *ev;
   Evas_Object         *edje_obj;

   ev = (Evas_Event_Key_Down *)einfo;
   edje_obj = (Evas_Object *)data;

   if (!strcmp(ev->key, "Escape")) 
     {
        ecore_main_loop_quit();
     }
   else if (!strcmp(ev->key, "Right")) 
     {
        printf("%s pressed\n", ev->key);
        printf("signal: right_down\n\n");
        edje_object_signal_emit(edje_obj, "right_down", "");
        return;
    }
   else if (!strcmp(ev->key, "Left")) 
     {
        printf("%s pressed\n", ev->key);
        printf("signal: left_down\n\n");
        edje_object_signal_emit(edje_obj, "left_down", "");
        return;
   }
}

static Evas_Object *create_my_group(Evas *canvas, const char *text)
{
   Evas_Object *edje;
   edje = edje_object_add(canvas);
   if (!edje)
     {
        EINA_LOG_CRIT("could not create edje object!");
        return NULL;
     }
     // 'my_group' is the name of a group in the edc file
	if (!edje_object_file_set(edje, edje_local , "my_group"))
    {
       int err = edje_object_load_error_get(edje);
       const char *errmsg = edje_load_error_str(err);
      fprintf(stderr, "could not load 'group_name' from theme.edj: %s",
       	errmsg);
 
       evas_object_del(edje);
       return NULL;
    }

   if (text)
     // 'text' is the name of a part in the edc file
        if (!edje_object_part_text_set(edje, "text", text))
          {
             EINA_LOG_WARN("could not set the text. "
                           "Maybe part 'text' does not exist");
          }

   evas_object_move(edje, 0, 0);
   evas_object_resize(edje, WIDTH, HEIGHT);
   evas_object_show(edje);
   return edje;
}

int main(int argc, char *argv[])
{ 
//printf("\nARGC = %d\n",argc);
//printf("\nARGV[1] = %s\n",argv[1]);
   Ecore_Evas *window;
   Evas *canvas;
   Evas_Object *edje;
   const char *text;
  
   ecore_evas_init();
   edje_init();

   window = ecore_evas_new(NULL, 0, 0, WIDTH, HEIGHT, NULL);
   if (!window)
     {
        EINA_LOG_CRIT("could not create window.");
        return -1;
     }
   canvas = ecore_evas_get(window);

   text = (argc > 1) ? argv[1] : NULL;

   edje = create_my_group(canvas, text);
   if (!edje)
     return -2;
     
   fprintf(stdout, commands);
   evas_object_focus_set(edje, EINA_TRUE);

   evas_object_event_callback_add(edje, EVAS_CALLBACK_KEY_DOWN, _on_keydown, edje);
   
   ecore_evas_show(window);
   ecore_main_loop_begin();
   
  // evas_object_del(edje);
  // ecore_evas_free(window);

   edje_shutdown();
   ecore_evas_shutdown();
 
   return 0;
}

